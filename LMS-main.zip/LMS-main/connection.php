<?php


$host = "localhost";
$username = "root";
$password = "";
$dbname = "finance";

$conn= mysqli_connect($host, $username, $password, $dbname);
/*
if ($conn) {


	echo "Connection Established Succesfully";

}
else{


	echo "connection error";
}
*/
?>
